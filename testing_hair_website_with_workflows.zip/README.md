# testing_hair_website

Full-stack example: React frontend + Express backend using Stripe Checkout and Firebase Firestore.
This is a developer-focused starter project. **Fill in .env values before running.**

Structure:
- frontend/ : React app (run `npm install` then `npm start`)
- backend/  : Express server (run `npm install` then `node index.js`)

See frontend/README.md and backend/README.md for step-by-step instructions.
