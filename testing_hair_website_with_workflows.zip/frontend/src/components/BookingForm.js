import React, { useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';

const stripePromise = loadStripe(process.env.REACT_APP_STRIPE_PUBLISHABLE_KEY);

export default function BookingForm({ stylist, onCancel }) {
  const [name, setName] = useState('Test Client');
  const [email, setEmail] = useState('test@example.com');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [service, setService] = useState('Cut');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`${process.env.REACT_APP_BACKEND_URL}/create-checkout-session`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ stylist, name, email, date, time, service })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to create checkout session');
      const stripe = await stripePromise;
      const { sessionId } = data;
      const { error } = await stripe.redirectToCheckout({ sessionId });
      if (error) setError(error.message);
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} style={{background:'white', padding:20, borderRadius:12}}>
      <h2 style={{fontSize:18, marginBottom:12}}>Book & Pay — {stylist.name}</h2>
      <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:12}}>
        <label style={{display:'flex', flexDirection:'column'}}>
          <span style={{fontSize:12, color:'#666'}}>Your name</span>
          <input required value={name} onChange={e=>setName(e.target.value)} style={{padding:12, borderRadius:8, border:'1px solid #ddd'}} />
        </label>
        <label style={{display:'flex', flexDirection:'column'}}>
          <span style={{fontSize:12, color:'#666'}}>Email</span>
          <input required value={email} onChange={e=>setEmail(e.target.value)} type='email' style={{padding:12, borderRadius:8, border:'1px solid #ddd'}} />
        </label>
        <label style={{display:'flex', flexDirection:'column'}}>
          <span style={{fontSize:12, color:'#666'}}>Service</span>
          <select value={service} onChange={e=>setService(e.target.value)} style={{padding:12, borderRadius:8, border:'1px solid #ddd'}}>
            <option>Cut</option>
            <option>Color</option>
            <option>Balayage</option>
            <option>Extensions</option>
            <option>Styling</option>
          </select>
        </label>
        <label style={{display:'flex', flexDirection:'column'}}>
          <span style={{fontSize:12, color:'#666'}}>Date</span>
          <input required type='date' value={date} onChange={e=>setDate(e.target.value)} style={{padding:12, borderRadius:8, border:'1px solid #ddd'}} />
        </label>
        <label style={{display:'flex', flexDirection:'column'}}>
          <span style={{fontSize:12, color:'#666'}}>Time</span>
          <input required type='time' value={time} onChange={e=>setTime(e.target.value)} style={{padding:12, borderRadius:8, border:'1px solid #ddd'}} />
        </label>
        <div style={{gridColumn:'1 / -1', display:'flex', gap:8}}>
          <button disabled={loading} type='submit' style={{flex:1, padding:12, borderRadius:999, background:'#c49a44', color:'white'}}> {loading ? 'Redirecting...' : `Pay $${stylist.price}`} </button>
          <button type='button' onClick={onCancel} style={{padding:12, borderRadius:999, background:'#eee'}}>Cancel</button>
        </div>
      </div>
      {error && <div style={{color:'red', marginTop:8}}>{error}</div>}
      <div style={{fontSize:12, color:'#666', marginTop:8}}>You will be redirected to Stripe Checkout to complete payment.</div>
    </form>
  );
}
