import React, { useEffect, useState } from 'react';

export default function Success() {
  const [booking, setBooking] = useState(null);
  const [loading, setLoading] = useState(true);
  const params = new URLSearchParams(window.location.search);
  const sessionId = params.get('session_id');

  useEffect(() => {
    async function fetchBooking() {
      if (!sessionId) return setLoading(false);
      try {
        const res = await fetch(`${process.env.REACT_APP_BACKEND_URL}/booking/${sessionId}`);
        if (!res.ok) throw new Error('Booking not found');
        const data = await res.json();
        setBooking(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    fetchBooking();
  }, [sessionId]);

  if (loading) return <div style={{padding:20}}>Loading receipt...</div>;
  if (!booking) return <div style={{padding:20}}>No booking found. If you were redirected here and do not see details, contact support.</div>;

  return (
    <div style={{padding:24, maxWidth:800, margin:'0 auto'}}>
      <h1 style={{fontSize:22, fontWeight:700}}>Payment Successful</h1>
      <p style={{color:'#666'}}>Thank you, {booking.client_name} — your booking is confirmed.</p>

      <div style={{background:'white', padding:16, borderRadius:12, marginTop:12}}>
        <div style={{fontWeight:700}}>{booking.service} — {booking.stylist_name}</div>
        <div style={{color:'#666', fontSize:13}}>{booking.date} at {booking.time}</div>
        <div style={{marginTop:8}}>
          <div>Amount paid: ${(booking.amount_total/100).toFixed(2)} {booking.currency.toUpperCase()}</div>
          <div style={{fontSize:12, color:'#888', marginTop:6}}>Reference: {booking.id}</div>
        </div>
      </div>
    </div>
  );
}
