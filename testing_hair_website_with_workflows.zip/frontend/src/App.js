import React, { useState, useEffect } from 'react';
import BookingForm from './components/BookingForm';
import Success from './Success';
import Cancel from './Cancel';

const STYLISTS = [
  { id: 1, name: 'Ariana', specialty: 'Color & Balayage', price: 120, img: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=800&q=60' },
  { id: 2, name: 'Maya', specialty: 'Cuts & Styling', price: 75, img: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=800&q=60' },
  { id: 3, name: 'Sam', specialty: 'Extensions', price: 200, img: 'https://images.unsplash.com/photo-1551854838-0b8aef9a4c6f?w=800&q=60' }
];

function StylistCard({ s, onSelect }) {
  return (
    <div style={{background:'white', padding:12, borderRadius:16, display:'flex', gap:12, alignItems:'center'}}>
      <img src={s.img} alt={s.name} style={{width:64, height:64, borderRadius:999, objectFit:'cover'}} />
      <div style={{flex:1}}>
        <div style={{display:'flex', justifyContent:'space-between'}}>
          <div>
            <div style={{fontWeight:700}}>{s.name}</div>
            <div style={{fontSize:12, color:'#666'}}>{s.specialty}</div>
          </div>
          <div style={{textAlign:'right'}}>
            <div style={{fontSize:12, color:'#666'}}>From</div>
            <div style={{fontWeight:700}}>${s.price}</div>
          </div>
        </div>
        <div style={{marginTop:8}}>
          <button onClick={() => onSelect(s)} style={{padding:'8px 14px', borderRadius:999, background:'#ff6fa3', color:'white'}}>Select</button>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [bookingOpen, setBookingOpen] = useState(false);
  const [selectedStylist, setSelectedStylist] = useState(STYLISTS[0]);
  const [bookings, setBookings] = useState([]);
  const [confirmation, setConfirmation] = useState(null);

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem('local_bookings') || '[]');
    setBookings(saved);
  }, []);

  useEffect(() => {
    localStorage.setItem('local_bookings', JSON.stringify(bookings));
  }, [bookings]);

  function openBookingWith(stylist) {
    setSelectedStylist(stylist);
    setBookingOpen(true);
  }

  function addLocalBooking(b) {
    const id = Math.random().toString(36).slice(2,9).toUpperCase();
    const newB = { id, ...b };
    setBookings([...bookings, newB]);
    setConfirmation(newB);
    setBookingOpen(false);
  }

  function deleteBooking(id) {
    setBookings(bookings.filter(b => b.id !== id));
  }

  // Simple routing for /success and /cancel (client-side)
  const path = window.location.pathname;
  if (path === '/success') return <Success />;
  if (path === '/cancel') return <Cancel />;

  return (
    <div className='container'>
      <header style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:20}}>
        <div style={{display:'flex', gap:12, alignItems:'center'}}>
          <div style={{width:48, height:48, borderRadius:999, background:'#c49a44', color:'white', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:700}}>LG</div>
          <div>
            <div style={{fontWeight:700}}>Lux Glam Studio</div>
            <div style={{fontSize:12, color:'#666'}}>Gold & Pink Hair Bar</div>
          </div>
        </div>
        <div>
          <button onClick={() => setBookingOpen(true)} style={{padding:'8px 12px', borderRadius:999, background:'#ff6fa3', color:'white'}}>Book</button>
        </div>
      </header>

      <section style={{marginBottom:24}}>
        <h2 style={{fontSize:20, fontWeight:700}}>Our Stylists</h2>
        <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(260px, 1fr))', gap:12}}>
          {STYLISTS.map(s => <StylistCard key={s.id} s={s} onSelect={openBookingWith} />)}
        </div>
      </section>

      <section style={{marginBottom:24}}>
        <h2 style={{fontSize:20, fontWeight:700}}>Your Bookings (local)</h2>
        {bookings.length === 0 ? (
          <div style={{color:'#666'}}>No bookings yet.</div>
        ) : (
          <div style={{display:'grid', gap:12}}>
            {bookings.map(b => (
              <div key={b.id} style={{display:'flex', justifyContent:'space-between', alignItems:'center', background:'white', padding:12, borderRadius:12}}>
                <div>
                  <div style={{fontWeight:700}}>{b.client_name || b.name}</div>
                  <div style={{fontSize:12, color:'#666'}}>{b.service} with {b.stylist?.name || b.stylist_name} — {b.date} at {b.time}</div>
                  <div style={{fontWeight:700, color:'#ff6fa3'}}>${b.price}</div>
                </div>
                <div>
                  <button onClick={() => deleteBooking(b.id)} style={{background:'transparent', border:'none', color:'#888'}} title="Delete">Delete</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {bookingOpen && (
        <div style={{position:'fixed', inset:0, background:'rgba(0,0,0,0.45)', display:'flex', alignItems:'center', justifyContent:'center', padding:16}}>
          <div style={{width:'100%', maxWidth:720}}>
            <BookingForm stylist={selectedStylist} onCancel={() => setBookingOpen(false)} />
          </div>
        </div>
      )}

      {confirmation && (
        <div style={{position:'fixed', right:20, bottom:20, background:'white', padding:12, borderRadius:12, boxShadow:'0 8px 24px rgba(0,0,0,0.12)'}}>
          <div style={{display:'flex', gap:8, alignItems:'center'}}>
            <div style={{background:'#c49a44', color:'white', padding:8, borderRadius:999}}>✓</div>
            <div>
              <div style={{fontWeight:700}}>Booking Confirmed</div>
              <div style={{fontSize:12, color:'#666'}}>Ref: {confirmation.id} • {confirmation.date} @ {confirmation.time}</div>
            </div>
            <div style={{marginLeft:12}}>
              <button onClick={() => setConfirmation(null)} style={{background:'transparent', border:'none', color:'#666'}}>Dismiss</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
