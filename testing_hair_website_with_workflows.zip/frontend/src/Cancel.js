import React from 'react';

export default function Cancel(){
  return (
    <div style={{padding:24}}>
      <h1 style={{fontSize:22}}>Payment canceled</h1>
      <p style={{color:'#666'}}>Your payment was canceled. You can return to the site to try again.</p>
    </div>
  );
}
