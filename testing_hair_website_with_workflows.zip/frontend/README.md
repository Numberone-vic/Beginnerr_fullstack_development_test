# Frontend

1. Copy `frontend/.env.example` to `frontend/.env` and fill values.
2. Install dependencies: `cd frontend && npm install`
3. Start: `npm start` (opens at http://localhost:3000)
4. Make bookings and click Pay to be redirected to Stripe Checkout.
