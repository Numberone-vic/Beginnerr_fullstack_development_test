# Backend (Express + Stripe + Firestore)

1. Copy `backend/.env.example` to `backend/.env` and fill values.
2. Place your Firebase service account JSON at `backend/serviceAccountKey.json` (or set FIREBASE_SERVICE_ACCOUNT_JSON env).
3. Install dependencies: `cd backend && npm install`
4. Run: `node index.js`
5. For local webhook testing: `stripe listen --forward-to localhost:4242/webhook` and set the displayed `whsec_...` in your .env as STRIPE_WEBHOOK_SECRET
