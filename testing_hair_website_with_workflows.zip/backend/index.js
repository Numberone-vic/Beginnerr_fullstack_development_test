require('dotenv').config();
const express = require('express');
const Stripe = require('stripe');
const bodyParser = require('body-parser');
const cors = require('cors');
const admin = require('firebase-admin');
const fs = require('fs');

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);
const app = express();
const PORT = process.env.PORT || 4242;

// CORS origin
const allowedOrigin = process.env.CORS_ORIGIN || 'http://localhost:3000';
app.use(cors({ origin: allowedOrigin }));

// JSON parser for standard endpoints
app.use(express.json());

// Initialize Firebase Admin
try {
  if (process.env.FIREBASE_SERVICE_ACCOUNT_PATH && fs.existsSync(process.env.FIREBASE_SERVICE_ACCOUNT_PATH)) {
    const serviceAccount = require(process.env.FIREBASE_SERVICE_ACCOUNT_PATH);
    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount),
      databaseURL: process.env.FIREBASE_DATABASE_URL
    });
  } else if (process.env.FIREBASE_SERVICE_ACCOUNT_JSON) {
    const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON);
    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount),
      databaseURL: process.env.FIREBASE_DATABASE_URL
    });
  } else {
    console.error('Firebase service account not configured. Use FIREBASE_SERVICE_ACCOUNT_PATH or FIREBASE_SERVICE_ACCOUNT_JSON');
    // don't exit here so dev can still run some endpoints without Firestore, but warn.
  }
} catch (err) {
  console.error('Failed to initialize Firebase Admin', err);
}

const db = admin.firestore ? admin.firestore() : null;

// Optional SendGrid setup
let sgMail = null;
try {
  sgMail = require('@sendgrid/mail');
  if (process.env.SENDGRID_API_KEY) sgMail.setApiKey(process.env.SENDGRID_API_KEY);
} catch (e) {
  sgMail = null;
  console.warn('SendGrid not initialized - email sending disabled unless you install @sendgrid/mail and set SENDGRID_API_KEY');
}

/**
 * Create Checkout Session
 * Expects body: { stylist: {id,name,price,...}, name, email, date, time, service }
 */
app.post('/create-checkout-session', async (req, res) => {
  try {
    const { stylist, name, email, date, time, service } = req.body;
    if (!stylist || !name || !email || !date || !time || !service) {
      return res.status(400).json({ error: 'Missing required booking fields' });
    }

    const amount = Math.round((stylist.price || 0) * 100);

    const metadata = {
      stylist_id: String(stylist.id),
      stylist_name: stylist.name,
      client_name: name,
      client_email: email,
      service,
      date,
      time
    };

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      line_items: [
        {
          price_data: {
            currency: 'usd',
            product_data: {
              name: `${service} — ${stylist.name}`,
              description: `Booking for ${service} with ${stylist.name} on ${date} at ${time}`
            },
            unit_amount: amount
          },
          quantity: 1
        }
      ],
      customer_email: email,
      metadata,
      success_url: `${process.env.CLIENT_SUCCESS_URL || 'http://localhost:3000/success'}?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.CLIENT_CANCEL_URL || 'http://localhost:3000/cancel'}`
    });

    return res.json({ sessionId: session.id });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// Webhook endpoint (Stripe requires raw body)
app.post('/webhook', bodyParser.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'];
  try {
    const event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);

    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      const metadata = session.metadata || {};

      const booking = {
        id: session.id,
        amount_total: session.amount_total,
        currency: session.currency,
        payment_status: session.payment_status,
        created: admin.firestore ? admin.firestore.Timestamp.fromMillis(session.created * 1000) : new Date(),
        stylist_id: metadata.stylist_id || null,
        stylist_name: metadata.stylist_name || null,
        client_name: metadata.client_name || null,
        client_email: metadata.client_email || null,
        service: metadata.service || null,
        date: metadata.date || null,
        time: metadata.time || null,
        stripe_payment_intent: session.payment_intent || null
      };

      try {
        if (db) {
          await db.collection('bookings').doc(session.id).set(booking, { merge: true });
          console.log('Booking saved to Firestore, session:', session.id);
        } else {
          console.log('Firestore not initialized; skipping save. Booking:', booking);
        }
      } catch (err) {
        console.error('Failed to save booking to Firestore:', err);
      }

      // Send confirmation email (optional)
      if (sgMail && process.env.SENDGRID_API_KEY && booking.client_email) {
        const msg = {
          to: booking.client_email,
          from: process.env.EMAIL_FROM || 'no-reply@luxglam.example',
          subject: `Your Lux Glam booking — ${booking.service} with ${booking.stylist_name}`,
          html: `
            <p>Hi ${booking.client_name || ''},</p>
            <p>Thanks for your booking. Your payment was received.</p>
            <p><strong>${booking.service} — ${booking.stylist_name}</strong><br/>${booking.date} @ ${booking.time}</p>
            <p>Amount: $${(booking.amount_total/100).toFixed(2)}</p>
            <p>Ref: ${booking.id}</p>
            <p>See you soon — Lux Glam Studio</p>
          `
        };
        try { await sgMail.send(msg); console.log('Confirmation email sent'); } catch (e) { console.error('Email failed', e); }
      }
    }

    res.json({ received: true });
  } catch (err) {
    console.error('Webhook signature verification failed.', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }
});

// Optional: get booking by session id
app.get('/booking/:sessionId', async (req, res) => {
  const sessionId = req.params.sessionId;
  try {
    if (!db) return res.status(500).json({ error: 'Firestore not initialized' });
    const doc = await db.collection('bookings').doc(sessionId).get();
    if (!doc.exists) return res.status(404).json({ error: 'Booking not found' });
    return res.json(doc.data());
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Internal error' });
  }
});

// Update booking (partial) - PATCH /booking/:sessionId
app.patch('/booking/:sessionId', express.json(), async (req, res) => {
  if (process.env.ADMIN_TOKEN && req.headers['x-admin-token'] !== process.env.ADMIN_TOKEN) {
    return res.status(401).json({ error: 'unauthorized' });
  }
  const id = req.params.sessionId;
  const updates = req.body;
  try {
    if (!db) return res.status(500).json({ error: 'Firestore not initialized' });
    await db.collection('bookings').doc(id).set(updates, { merge: true });
    return res.json({ ok: true });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed' });
  }
});

// Cancel booking - DELETE /booking/:sessionId
app.delete('/booking/:sessionId', async (req, res) => {
  if (process.env.ADMIN_TOKEN && req.headers['x-admin-token'] !== process.env.ADMIN_TOKEN) {
    return res.status(401).json({ error: 'unauthorized' });
  }
  const id = req.params.sessionId;
  try {
    if (!db) return res.status(500).json({ error: 'Firestore not initialized' });
    await db.collection('bookings').doc(id).delete();
    return res.json({ ok: true });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed' });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
